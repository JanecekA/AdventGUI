/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;

/*******************************************************************************
 * Třída PrikazBatoh implementuje pro hru příkaz batoh.
 *
 * @author    Antonio Janeček
 * @version   1.1
 */
public class PrikazBatoh implements IPrikaz
{
    //== Datové atributy (statické i instancí)======================================

    private static final String NAZEV = "batoh";
    private HerniPlan hPlan;
    //== Konstruktory a tovární metody =============================================

    /***************************************************************************
     *  Konstruktor ....
     *  @param hPlan, ve kterém je batoh pro přenášení předměty
     */
    public PrikazBatoh(HerniPlan hPlan)
    {
        this.hPlan = hPlan;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    /**
     *  Metoda pro provedení příkazu batoh. Metoda vrací seznam předměty, které jsou v batohu
     *  
     *  @return seznam předměty v batohu  
     */
    public String proved(String... parametry)
    {
        return hPlan.getBatoh().getPredmety();
    }

    /**
     *  Metoda vrací název příkazu
     *  
     *  @return nazev prikazu
     */
    public String getNazev()
    {
        return NAZEV;
    }

    //== Soukromé metody (instancí i třídy) ========================================

}
