/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/*******************************************************************************
 * Testovací třída BatohTest slouží ke komplexnímu otestování třídy Batoh
 *
 * @author    Antonio Janeček
 * @version   1.1
 */
public class BatohTest
{
    //== KONSTRUKTORY A TOVÁRNÍ METODY =========================================
    //-- Testovací třída vystačí s prázdným implicitním konstruktorem ----------

    /***************************************************************************
     * Inicializace předcházející spuštění každého testu a připravující tzv.
     * přípravek (fixture), což je sada objektů, s nimiž budou testy pracovat.
     */
    @Before
    public void setUp()
    {
    }

    /***************************************************************************
     * Úklid po testu - tato metoda se spustí po vykonání každého testu.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * Testuje, zda do batohu lze přidat předmět
     */
    @Test
    public void testPridat()
    {
        Batoh batoh1 = new Batoh();
        Predmet predmet1 = new Predmet("pred1","popis1", true);
        Predmet predmet2 = new Predmet("pred2", "popis2",false);
        Predmet predmet3 = new Predmet("pred3", "popis3",true);
        Predmet predmet4 = batoh1.vlozPredmet(predmet1);
        assertEquals(predmet4, predmet4);
        Predmet predmet5 = batoh1.vlozPredmet(predmet2);
        assertEquals(predmet5, predmet5);
        Predmet predmet6 = batoh1.vlozPredmet(predmet3);
        assertEquals(predmet6, predmet6);
    }

    /**
     * Testuje se kapacita batohu. Kolik věcí lze vložit do batohu
     */
    @Test
    public void testMaxPocet()
    {
        Batoh batoh1 = new Batoh();
        Predmet predmet1 = new Predmet("pred1","popis1", true);
        Predmet predmet2 = new Predmet("pred2", "popis2",false);
        Predmet predmet3 = new Predmet("pred3", "popis3",true);
        Predmet predmet4 = new Predmet("pred4", "popis4",true);
        Predmet predmet5 = new Predmet("pred5", "popis5",true);
        batoh1.vlozPredmet(predmet1);
        batoh1.vlozPredmet(predmet2);
        batoh1.vlozPredmet(predmet3);
        batoh1.vlozPredmet(predmet4);
        batoh1.vlozPredmet(predmet5);
        assertEquals(true, batoh1.obsahujePredmet("pred1"));
        assertEquals(true, batoh1.obsahujePredmet("pred3"));
        assertEquals(false, batoh1.obsahujePredmet("pred2"));
        assertEquals(true, batoh1.obsahujePredmet("pred4"));
        assertEquals(false, batoh1.obsahujePredmet("pred5"));
    }

    /**
     * Testuje úspěšné smazání věci z batohu
     */
    @Test
    public void testVyhodPredmet()
    {
        Batoh batoh1 = new Batoh();
        Predmet predmet1 = new Predmet("predmet1","popis", true);
        batoh1.vlozPredmet(predmet1);
        assertEquals(true, batoh1.obsahujePredmet("predmet1"));
        batoh1.smazPredmet("predmet1");
        assertEquals(false, batoh1.obsahujePredmet("predmet1"));
    }
    //== VLASTNÍ TESTY =========================================================
    //
    //     /********************************************************************
    //      *
    //      */
    //     @Test
    //     public void testXxx()
    //     {
    //     }
}
