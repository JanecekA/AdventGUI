/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/*******************************************************************************
 * Testovací třída PostavaTest slouží ke komplexnímu otestování třídy Postava
 *
 * @author    Tran Nhat Duc
 * @version   1.1
 */
public class PostavaTest
{
    //== KONSTRUKTORY A TOVÁRNÍ METODY =========================================
    //-- Testovací třída vystačí s prázdným implicitním konstruktorem ----------

    /***************************************************************************
     * Inicializace předcházející spuštění každého testu a připravující tzv.
     * přípravek (fixture), což je sada objektů, s nimiž budou testy pracovat.
     */
    @Before
    public void setUp()
    {
    }

    /***************************************************************************
     * Úklid po testu - tato metoda se spustí po vykonání každého testu.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * Testuje se postava. 
     */
    @Test
    public void testPostavy()
    {
        Predmet predmet1 = new Predmet("predmet1","popis", true);
        Predmet predmet2 = new Predmet("predmet2", "popis",false);
        Postava postava1 = new Postava("honza", "ahoj", "čau", "nechci", "díky", predmet1, predmet2);
        assertEquals("nechci", postava1.getRecNechci());
        assertNotNull(postava1.getPredmetChce());
        postava1.setProbehlaVymena(true);
    }
    //== VLASTNÍ TESTY =========================================================
    //
    //     /********************************************************************
    //      *
    //      */
    //     @Test
    //     public void testXxx()
    //     {
    //     }
}
