package logika;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/*******************************************************************************
 * Testovací třída HraTest slouží ke komplexnímu otestování
 * třídy Hra
 *
 * @author     Jarmila Pavlíčková, Jan Říha, Antonio Janeček
 * @version    1.1
 */
public class HraTest {
    private Hra hra1;

    //== Datové atributy (statické i instancí)======================================

    //== Konstruktory a tovární metody =============================================
    //-- Testovací třída vystačí s prázdným implicitním konstruktorem ----------

    //== Příprava a úklid přípravku ================================================

    /***************************************************************************
     * Metoda se provede před spuštěním každé testovací metody. Používá se
     * k vytvoření tzv. přípravku (fixture), což jsou datové atributy (objekty),
     * s nimiž budou testovací metody pracovat.
     */
    @Before
    public void setUp() {
        hra1 = new Hra();
    }

    /***************************************************************************
     * Úklid po testu - tato metoda se spustí po vykonání každé testovací metody.
     */
    @After
    public void tearDown() {
    }

    //== Soukromé metody používané v testovacích metodách ==========================

    //== Vlastní testovací metody ==================================================

    /***************************************************************************
     * Testuje průběh hry, po zavolání každěho příkazu testuje, zda hra končí
     * a v jaké aktuální místnosti se hráč nachází.
     * Při dalším rozšiřování hry doporučujeme testovat i jaké věci nebo osoby
     * jsou v místnosti a jaké věci jsou v batohu hráče.
     * 
     */
    @Test
    public void testPrubehHry() {
        assertEquals("cela", hra1.getHerniPlan().getAktualniLokace().getNazev());
        assertTrue(hra1.getHerniPlan().getAktualniLokace().obsahujePredmet("korbel"));
        hra1.zpracujPrikaz("seber korbel");
        hra1.zpracujPrikaz("pouzij korbel mriz");
        assertEquals(true, hra1.getHerniPlan().getBatoh().obsahujePredmet("korbel"));
        hra1.zpracujPrikaz("vyhod korbel");
        hra1.zpracujPrikaz("jdi koridor");
        hra1.zpracujPrikaz("jdi zbrojnice");        
        hra1.zpracujPrikaz("jdi koridor");
        assertEquals(true,hra1.getHerniPlan().getAktualniLokace().getJsemTadyByl());
        hra1.zpracujPrikaz("jdi zbrojnice");
        hra1.zpracujPrikaz("prozkoumej podstavec");
        hra1.zpracujPrikaz("seber sekyra");
        hra1.zpracujPrikaz("jdi koridor");
        hra1.zpracujPrikaz("vyhod korbel");
        hra1.zpracujPrikaz("jdi kasarna");
        hra1.zpracujPrikaz("seber prsten");
        hra1.zpracujPrikaz("pouzij sekyra zavora");
        hra1.zpracujPrikaz("jdi jidelna");
        assertEquals("jidelna", hra1.getHerniPlan().getAktualniLokace().getNazev());
        assertNotNull(hra1.getHerniPlan().getAktualniLokace().isPostava("pes"));
        hra1.zpracujPrikaz("vyhod sekyra");
        hra1.zpracujPrikaz("prozkoumej talir");
        hra1.zpracujPrikaz("seber kost");
        assertEquals(false, hra1.getHerniPlan().getBatoh().obsahujePredmet("kost"));
        hra1.zpracujPrikaz("dej pes kost");
        assertEquals(false, hra1.getHerniPlan().getBatoh().obsahujePredmet("kost"));
    }

    /**
     * Testuje, zda lze vyhrát - tj. dostatat do domečka
     * nejkratším možným způsobem
     */
    @Test
    public void testVyhraje()
    {
        assertEquals(false, hra1.konecHry());
        hra1.zpracujPrikaz("seber korbel");  //1
        hra1.zpracujPrikaz("pouzij korbel mriz");
        hra1.zpracujPrikaz("jdi koridor");
        hra1.zpracujPrikaz("jdi zbrojnice");
        hra1.zpracujPrikaz("prozkoumej podstavec");
        hra1.zpracujPrikaz("seber sekyra"); //2
        hra1.zpracujPrikaz("jdi koridor");
        hra1.zpracujPrikaz("vyhod korbel"); //1
        hra1.zpracujPrikaz("jdi kasarna");
        hra1.zpracujPrikaz("seber prsten"); //2
        hra1.zpracujPrikaz("pouzij sekyra zavora");
        hra1.zpracujPrikaz("jdi jidelna");
        hra1.zpracujPrikaz("vyhod sekyra"); //1
        hra1.zpracujPrikaz("prozkoumej talir");
        hra1.zpracujPrikaz("seber kost"); //2
        hra1.zpracujPrikaz("dej pes kost"); //2
        hra1.zpracujPrikaz("pouzij klika dvere"); //1
        hra1.zpracujPrikaz("jdi sklad");
        hra1.zpracujPrikaz("seber paka"); //2
        hra1.zpracujPrikaz("jdi jidelna");
        hra1.zpracujPrikaz("pouzij paka dira"); //1
        hra1.zpracujPrikaz("jdi tajna_komora");
        hra1.zpracujPrikaz("dej kostlivec prsten"); //1
        hra1.zpracujPrikaz("jdi jidelna");
        hra1.zpracujPrikaz("pouzij klic brana");
        hra1.zpracujPrikaz("jdi chodba");
        hra1.zpracujPrikaz("jdi knihovna");
        hra1.zpracujPrikaz("vyhod klic"); //0
        hra1.zpracujPrikaz("prozkoumej stul");
        hra1.zpracujPrikaz("seber kniha"); //1
        hra1.zpracujPrikaz("seber denik"); //2
        hra1.zpracujPrikaz("pouzij denik kniha"); //3
        hra1.zpracujPrikaz("vyhod denik"); //2
        hra1.zpracujPrikaz("jdi chodba");
        hra1.zpracujPrikaz("pouzij kniha runa");
        hra1.zpracujPrikaz("jdi vez");
        hra1.zpracujPrikaz("pouzij kouzlo carodejnice"); //2
        hra1.zpracujPrikaz("pouzij krystal kotouc"); //1
        hra1.zpracujPrikaz("jdi povrch");
        assertEquals(true, hra1.konecHry());
    }

}
