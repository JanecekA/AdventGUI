/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/*******************************************************************************
 * Testovací třída PredmetTest slouží ke komplexnímu otestování třídy Predmet
 *
 * @author    Antonio Janeček
 * @version   1.1
 */
public class PredmetTest
{
    //== KONSTRUKTORY A TOVÁRNÍ METODY =========================================
    //-- Testovací třída vystačí s prázdným implicitním konstruktorem ----------

    /***************************************************************************
     * Inicializace předcházející spuštění každého testu a připravující tzv.
     * přípravek (fixture), což je sada objektů, s nimiž budou testy pracovat.
     */
    @Before
    public void setUp()
    {
    }

    /***************************************************************************
     * Úklid po testu - tato metoda se spustí po vykonání každého testu.
     */
    @After
    public void tearDown()
    {
    }

    /**
     * Testuje se zda lze vlozit a najde věc ve předmět
     */
    @Test
    public void testNajdiVecVeVeci()
    {
        Predmet predmet1 = new Predmet("predmet1","popis", true);
        Predmet predmet2 = new Predmet("predmet2", "popis",false);
        Predmet predmet3 = new Predmet("predmet3", "popis",true);

        predmet3.vlozPredmet(predmet1);
        predmet2.vlozPredmet(predmet1);
        assertEquals(true, predmet3.obsahujePredmet("predmet1"));
        assertEquals(false, predmet3.obsahujePredmet("predmet2"));
    }
    //== VLASTNÍ TESTY =========================================================
    //
    //     /********************************************************************
    //      *
    //      */
    //     @Test
    //     public void testXxx()
    //     {
    //     }
}
