/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;

/*******************************************************************************
 * Třída PrikazVydod implementuje pro hru příkaz vyhod.
 *
 * @author    Antonio Janeček
 * @version   LS 2016/2017
 */
public class PrikazVyhod implements IPrikaz
{
    //== Datové atributy (statické i instancí)======================================
    private static final String NAZEV = "vyhod";
    private HerniPlan hPlan;
    //== Konstruktory a tovární metody =============================================

    /***************************************************************************
     *  Konstruktor ....
     *  @param hPlan, herní plán, ve kterém se budou jednotlivé věci vyhodit na zemi.
     */
    public PrikazVyhod(HerniPlan hPlan)
    {
        this.hPlan = hPlan;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    /**
     *  Metoda pro provedení příkazu vyhod. Vyhodí se předmět z batohu, pokud daný předmět v batohu.
     *  
     *  @param předmět, kterou chceme vyhodit z batohu
     *  @return zpráva, kterou vypíše hráči
     */
    public String proved(String... parametry)
    {
        if (parametry.length == 0)
        {
            return "Zadejte název požadované věci, kterou chcete vyhodit.";
        }

        if (parametry.length > 1)
        {
            return "Nemuzes vyhodit vic veci najednou!";
        }
        String predmet = parametry[0];
        Batoh batoh = hPlan.getBatoh();
        Predmet vymazana = batoh.smazPredmet(predmet);
        if (vymazana != null)
        {
            hPlan.getAktualniLokace().vlozPredmet(vymazana);
            return "Prave jsi vyhodil " + predmet;
        }
        return "Takovou věc v batohu nemáš!";
    }

    /**
     *  Metoda vrací název příkazu
     *  
     *  @return nazev prikazu
     */
    public String getNazev()
    {
        return NAZEV;
    }

    //== Soukromé metody (instancí i třídy) ========================================

}
