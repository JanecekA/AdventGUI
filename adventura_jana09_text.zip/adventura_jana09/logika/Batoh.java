/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;
import java.util.*;

/*******************************************************************************
 * Instance třídy Batoh představují přenositelný batoh ve hře.
 *
 * Batoh slouží pro ukládání věcí a tak máme s sebou.
 * Batoh je omezen kapacitou. Do batohu lze ukládat určitý počet věcí.
 * 
 * @author    Antonio Janeček
 * @version   1.1
 */
public class Batoh
{
    //== Datové atributy (statické i instancí)======================================
    public static final int MAXIMALNI_POCET = 3;
    private List<Predmet> obsah;
    //== Konstruktory a tovární metody =============================================

    /***************************************************************************
     *  Konstruktor třídy
     */
    public Batoh()
    {
        obsah = new ArrayList<Predmet>();
    }

    /**
     * Metoda pro vložení předměty do batohu
     * @param předmět, název předmět
     * @return vrací předmět nebo null, pokud už není místo nebo předmět je nepřenositelný
     */
    public Predmet vlozPredmet (Predmet pridat)
    {
        if (jeMisto()&&pridat.isPrenositelny()) {
            obsah.add(pridat);
            return pridat;
        }
        return null;
    }

    /**
     * Metoda pro zjisteni jestli je misto v batohu
     * @return vrací false pokud už není místo v batohu
     */
    public boolean jeMisto()
    {
        if (obsah.size() < MAXIMALNI_POCET) {
            return true;
        }
        return false;
    }

    /**
     * Metoda pro hledání předmětů v batohu
     * @param předmět, název předmět
     * @return vrací true, pokud se podařilo nalézt věc v batohu, v opačném případě vrací false
     */
    public boolean obsahujePredmet(String hledany)
    {
        for (Predmet predmet:obsah)
        {
            if (predmet.getNazev().equals(hledany))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Metoda pro vypsání seznamu všech věcí v batohu
     * @return obsah batohu
     */
    public String getPredmety() {
        String seznam = "V batohu máš ";
        if (obsah.isEmpty())
        {
            return "V batohu nic nemáš!";
        }
        else {
            for (Predmet aktualni: obsah) {
                if (!seznam.equals("")) {
                    //pro větší přehlednost dáme čárku
                    seznam += ",";
                }
                seznam += " " + aktualni.getNazev();
            }}
        return seznam;
    }

    /**
     * Metoda pro hledání předměty v batohu
     * @param předmět, název předmět
     * @return vrací true, pokud se podařilo nalézt předmět v batohu, v opačném případě vrací false
     */
    public Predmet getPredmet(String nazev) {
        Predmet hledana = null;
        for (Predmet aktualni: obsah) {
            if(aktualni.getNazev().equals(nazev)) {
                hledana = aktualni;
                break;
            }
        }
        return hledana;
    }

    /**
     * Metoda pro odebrání předměty z batohu
     * @param předmět, název věci
     * @return vrací věc, pokud odebíráná věc je v batohu, nebo vrací null pokud odebíraná věc není v batohu 
     */
    public Predmet smazPredmet (String mazana) {
        Predmet smazana = null;
        for (Predmet predmet: obsah) {
            if(predmet.getNazev().equals(mazana)) {
                smazana = predmet;
                obsah.remove(predmet);
                break;
            }
        }
        return smazana;
    }

    /**
     * Metoda vrácí max. počet předmětu v batohu
     * 
     * @return vrací max. počet předmětu v batohu
     */
    public int getMaxPocet()
    {
        return MAXIMALNI_POCET;
    }
    //== Nesoukromé metody (instancí i třídy) ======================================

    //== Soukromé metody (instancí i třídy) ========================================
}
