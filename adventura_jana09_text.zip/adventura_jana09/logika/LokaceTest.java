package logika;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/*******************************************************************************
 * Testovací třída LokaceTest slouží ke komplexnímu otestování
 * třídy Lokace
 *
 * @author     Jarmila Pavlickova, Jan Riha, Antonio Janeček
 * @version    1.1
 */
public class LokaceTest
{
    //== Datové atributy (statické i instancí)======================================

    //== Konstruktory a tovární metody =============================================
    //-- Testovací třída vystačí s prázdným implicitním konstruktorem ----------

    //== Příprava a úklid přípravku ================================================

    /***************************************************************************
     * Metoda se provede před spuštěním každé testovací metody. Používá se
     * k vytvoření tzv. přípravku (fixture), což jsou datové atributy (objekty),
     * s nimiž budou testovací metody pracovat.
     */
    @Before
    public void setUp() {
    }

    /***************************************************************************
     * Úklid po testu - tato metoda se spustí po vykonání každé testovací metody.
     */
    @After
    public void tearDown() {
    }

    //== Soukromé metody používané v testovacích metodách ==========================

    //== Vlastní testovací metody ==================================================

    /**
     * Testuje, zda jsou správně nastaveny průchody mezi prostory hry.
     * 
     */
    @Test
    public  void testLzeProjit() {		
        Lokace lokace1 = new Lokace("doma", "v Praze");
        Lokace lokace2 = new Lokace("venku", "na Metro");
        lokace1.setVychod(lokace2);
        lokace2.setVychod(lokace1);
        assertEquals(lokace2, lokace1.vratSousedniLokaci("venku"));
        assertEquals(null, lokace2.vratSousedniLokaci("pokoj"));
    }

    /**
     * Testuje se vložení předmět a následně zda předmět najdem.
     */
    @Test
    public void testVeci()
    {
        Lokace lokace1 = new Lokace(null, null);
        Predmet predmet1 = new Predmet("a", "popis a", true);
        lokace1.vlozPredmet(predmet1);
        assertTrue(lokace1.obsahujePredmet("a"));
        assertFalse(lokace1.obsahujePredmet("c"));
    }

    /**
     * Testuje se vložení postavy a následně zda postavu najdem.
     */
    @Test
    public void testProstavVProstoru()
    {
        Lokace prostor1 = new Lokace("les", "Les");
        Postava postava1 = new Postava("honza", "ahoj", "nechci");
        Postava postava2 = new Postava("pepa", "jak se máš?", "nechci");
        prostor1.vlozPostavu(postava1);
        prostor1.vlozPostavu(postava2);
        assertNotNull(prostor1.isPostava("pepa"));
        assertNotNull(prostor1.isPostava("honza"));
        assertNull(prostor1.isPostava("mike"));
    }

}
