/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;

/*******************************************************************************
 * Třída PrikazDej implementuje pro hru příkaz dej.
 *
 * @author    Tran Nhat Duc
 * @version   1.1
 */
public class PrikazDej implements IPrikaz
{
    //== Datové atributy (statické i instancí)======================================
    private static final String NAZEV = "dej";
    private HerniPlan hPlan;
    //== Konstruktory a tovární metody =============================================

    /***************************************************************************
     *  Konstruktor ....
     *  @param hPlan (herní plán) ve kterém budou dát předměty pro jednotlivé postavy
     */
    public PrikazDej(HerniPlan hPlan)
    {
        this.hPlan = hPlan;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    /**
     *  Metoda pro provedení příkazu dej. 
     *  Aby bylo možné dát postavě věc, musí splnit tyto předpoklady:
     *  postava musí byt v aktualním lokaci, postava předávanou věc chce, musí předávaná předmět být v batohu,
     *  v batohu musí být dostatek prostoru pro věc co dostane na oplátku.
     *  Nelze vyměnit 2x.
     *  @param postava, komu chceme předmět dát
     *  @param předmět, kterou chceme dát
     *  @return zpráva, kterou vypíše hráči
     */
    public String proved(String... parametry)
    {
        if (parametry.length < 2)
        {
            return "Příkaz musí mít právě dva parametry, osobu a pak předmět.";
        }
        String osoba = parametry[0];
        String predmet = parametry[1];
        Lokace aktualniLokace = hPlan.getAktualniLokace();
        Postava postava = aktualniLokace.isPostava(osoba);
        Batoh batoh = hPlan.getBatoh();
        Predmet vec = batoh.getPredmet(predmet);
        if (vec == null)
        {
            return "Takový předmět v batohu nemáš";
        }

        if (postava == null)
        {
            return "Tato postava zde není";
        }

        if (postava.probehlaVymena())
        {
            return "Postava už nic nechce vyměnit!";
        }

        if (vec.equals(postava.getPredmetChce()))
        {
            batoh.vlozPredmet(postava.getPredmetMa());
            batoh.smazPredmet(predmet);
            postava.setProbehlaVymena(true);
            return osoba + ": " + postava.getRecChci() + "\nPrávě jsi dal " + vec.getNazev() + ", postavě " + postava.getJmeno()
            + " a dostal jsi za odměnu " + postava.getPredmetMa().getNazev() + ".";
        }
        return osoba + ": " + postava.getRecNechci() + ".";
    }

    /**
     *  Metoda vrací název příkazu
     *  
     *  @return nazev prikazu
     */
    public String getNazev()
    {
        return NAZEV;
    }

    //== Soukromé metody (instancí i třídy) ========================================

}
