/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;
import java.util.*;

/**
 * Třída PrikazProzkoumej implementuje pro hru příkaz prozkoumej.
 * Tato třída je součástí jednoduché textové hry.
 *
 * @author     Jan Riha, Antonio Janeček
 * @version    1.1
 */
public class PrikazProzkoumej implements IPrikaz

{
    private static final String NAZEV = "prozkoumej";

    private HerniPlan hPlan;

   
    
    /**
     * Konstruktor třídy
     *
     * @param    plan herní plán, ve kterém se bude ve hře "chodit" 
     */  
    public PrikazProzkoumej(HerniPlan hPlan)
    {
        this.hPlan = hPlan;
    }

    /**
     * Provádí příkaz "prozkoumej". Pokud nebyl zadán žádný parametr, vrátí kompletní
     * popis aktuální lokace. Pokud byl zadán jeden parametr, pokusí se v aktuální lokaci
     * a následně v batohu najít předmět s daným názvem a vrátit jeho popis. Pokud bylo
     * zadáno více parametrů, vrátí chybové hlášení.
     *
     * @param     parametry může jako parametr obsahovat název předmětu, který chce hráč prozkoumat
     * @return    zpráva, kterou vypíše hra hráči
     */ 
    @Override
    public String proved(String... parametry)
    {
        if (parametry.length > 1)
        {
            return "Tomu nerozumím, nemůžeš prozkoumat více předmětů najednou";
        }

        Lokace aktLokace = hPlan.getAktualniLokace();
        LinkedHashMap<String, Predmet> okoli = new LinkedHashMap<String,Predmet>( aktLokace.getPredmety());

        if (parametry.length > 0)
        {
            // Vypis popis predmetu
            String nazevPredmetu = parametry[0];

            if(aktLokace.obsahujePredmet(nazevPredmetu))
            {
                Predmet predmet = aktLokace.najdiPredmet(nazevPredmetu);
                Collection<Predmet> veci =  predmet.getVeciUvnitr();
                
                predmet.setProzkoumana(true);
                
                
                if(!veci.isEmpty())
                {
                    for(Predmet a : veci)
                    {
                    	
                    	a.setProzkoumana(true);
                        //
                        Batoh batoh = hPlan.getBatoh();
                        for (Predmet element : veci) {
                        	aktLokace.vezmiPredmet(element.getNazev());
                        	aktLokace.vlozPredmet(element);
                        	predmet.setPrenositelny(true);
                            aktLokace.vezmiPredmet(nazevPredmetu);
                            aktLokace.vlozPredmet(predmet);
                            predmet.setPrenositelny(false);
                            predmet.setProzkoumana(true);
                            
                            
                            
                            System.out.println(okoli+":okoli");
                            
                            
                            
                            List<String> others = new ArrayList<>();
                            for (String str : aktLokace.getPredmety().keySet()) {
                                if (!str.equals(element.getNazev())) {
                                    others.add(str);

                                    System.out.println(others+":listVen");

                                    System.out.println(element.getNazev()+":element");
                                    System.out.println(str+":promenaVen");
                                }
                            }
                            System.out.println(okoli+":okoliPredOd");
                            aktLokace.getPredmety().keySet().removeAll(others);
                            
                            
                            
                            
                            System.out.println(okoli+":okoliPredPrid");
                            System.out.println(aktLokace.getPredmety()+":predmetyPredPrid");
                            for (String b : okoli.keySet() ) {
                            	
                            	
                            	System.out.println(b+":bPred");
                               // System.out.println(prehod+":prehodPred");
                                
                                System.out.println(element.getNazev()+":elePred");
                            	
                                aktLokace.getPredmety().putAll(okoli);
                                System.out.println(aktLokace.getPredmety()+":predmetyPoPrid");
                                
                                
                                
                                
                            	/*if (!b.equals(element.getNazev())){
                            		Predmet prehod = okoli.Predmety.get
                            		//Predmet prehod = aktLokace.najdiPredmet(b);
                            		prehod.setPrenositelny(true);
                                aktLokace.vlozPredmet(prehod);
                                prehod.setProzkoumana(true);
                                System.out.println(element+":ele");
                                System.out.println(b+":b");
                                System.out.println(prehod+":prehod");
                                System.out.println(nazevPredmetu+":Pruzkum");
                                prehod.setPrenositelny(false);

                            	}*/
                            	
                            	
                            }
                            
                            
                            batoh.notifyAlllObservers();
                        	return "Našel(a) jsi předmět " + element;
                        	//aktLokace.vlozPredmet(predmet);
                        	
                    		
                    		
                        }
                        
                        
                        /*if (!batoh.jeMisto())
                        {
                            
                        	for (Predmet element : veci) {
                        		aktLokace.vlozPredmet(element);
                                
                            }
                        	
                            return "V batohu uz nemas volne misto, musis neco zahodit";
                        }

                        for (Predmet element : veci) {
                        	batoh.vlozPredmet(element);
                            return "Sebral(a) jsi predmet " + element;
                        }*/
                        //
                    }
                }
                
                return predmet.popisProzkoumej();
            }

            Batoh batoh = hPlan.getBatoh();
            if(batoh.obsahujePredmet(nazevPredmetu))
            {
                Predmet predmet = batoh.getPredmet(nazevPredmetu);
                predmet.setProzkoumana(true);
                return predmet.popisProzkoumej();
            }

            return "Předmět " + nazevPredmetu + " není v batohu ani v aktuální lokaci";
        }
        else
        {
            // Zobraz popis aktualni lokace
            return aktLokace.dlouhyPopis();
        }
    }

    /**
     * Metoda vrací název příkazu (slovo které používá hráč pro jeho vyvolání).
     *
     * @return    název příkazu
     */
    @Override
    public String getNazev()
    {
        return NAZEV;
    }
    
    

    
}
