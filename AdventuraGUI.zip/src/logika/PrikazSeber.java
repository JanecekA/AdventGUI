package logika;
import java.util.*;

/**
 * Třída představuje příkaz pro sebrání předmětu z aktuální lokace
 * a jeho vložení do batohu (inventáře) postavy.
 * 
 * @author     Jan Riha, Antonio Janeček
 * @version    1.1
 */
public class PrikazSeber implements IPrikaz
{
    private static final String NAZEV = "seber";

    private HerniPlan hPlan;

    public PrikazSeber(HerniPlan hPlan)
    {
        this.hPlan = hPlan;
    }

    /**
     * Metoda představuje zpracování příkazu pro sebrání předmětu.
     * Nejprve zkontroluje, zda byl zadán právě jeden název jako
     * parametr, ověří, zda v aktuální lokaci je předmět s tímto
     * názvem, zda je přenositelný, zda je v batohu místo a
     * následně předmět odebere z lokace a vloží ho do batohu.
     * 
     * @param parametry pole parametrů zadaných na příkazové řádce
     * @return výsledek zpracování, tj. text, který se vypíše na konzoli
     */
    public String proved(String... parametry)
    {        
        if (parametry.length < 1)
        {
            return "Nevim, co mam sebrat";
        }

        if (parametry.length > 1)
        {
            return "Tomu nerozumim, nedokazu sebrat vice veci najednou";
        }

        String nazevPredmetu = parametry[0];
        System.out.println(nazevPredmetu+"!nazevSeber");
        System.out.println(parametry[0]+"?parametrySeber");
        Lokace aktLokace = hPlan.getAktualniLokace();

        if (!aktLokace.obsahujePredmet(nazevPredmetu))
        {
            return "Predmet " + nazevPredmetu + " tady neni";
        }
        
       
       // Predmet predmet = aktLokace.vezmiPredmet(nazevPredmetu);
        Predmet predmet = aktLokace.najdiPredmet(nazevPredmetu);
        if(predmet == null)
        {
            return "Nemůžu " + nazevPredmetu + " odnést!!!!";
        }

        Batoh batoh = hPlan.getBatoh();
        if (!batoh.jeMisto())
        {
            aktLokace.vlozPredmet(predmet);
            return "V batohu uz nemas volne misto, musis neco zahodit";
            
        }
        if (predmet.isPrenositelny()){
        System.out.println(predmet.getNazev()+"!");
        batoh.vlozPredmet(predmet);
        aktLokace.vezmiPredmet(nazevPredmetu);
        return "Sebral(a) jsi predmet " + nazevPredmetu; 
        
        }
        else {
            
        return "nejde přenést!";
        }
    }

    /**
     * Metoda vrací název příkazu (slovo které používá hráč pro jeho vyvolání).
     *
     * @return    název příkazu
     */
    public String getNazev()
    {
        return NAZEV;
    }

}
