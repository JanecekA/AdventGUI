/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;
import java.util.*;
/**
 * Třída Predmet představuje jednotlivé předměty (věci), které je možné
 * ve hře najít.
 * 
 * Předmět může být přenositelný nebo nepřenositelný. Přenositelné předměty
 * je možné vložit do batohu postavy a přenášet mezi lokacemi. Nepřenositelné
 * předměty není možné z lokace odnést.
 *
 * @author     Jan Riha, Antonio Janeček
 * @version    1.1
 */
public class Predmet
{
    
	private String nazev;
    private String popis;
    private boolean prenositelny;
    private boolean prozkoumana;
    private List<Predmet> veciUvnitr;

    /**
     * Vytvoří nový předmět se zadaným názvem, popisem a přenositelností.
     * 
     * @param    nazev          název předmětu (jedno slovo)
     * @param    popis          popis předmětu (může se jednat o text libovolné délky)
     * @param    prenositelny   true, pokud má být předmět přenositelný; jinak false
     */
    public Predmet(String nazev, String popis, boolean prenositelny)
    {
        this.nazev = nazev;
        this.popis = popis;
        this.prenositelny = prenositelny;
        veciUvnitr=new ArrayList<>();
        this.prozkoumana = false;
    }

    /**
     * Vytvoří nový přenositelný předmět se zadaným názvem a popisem.
     * 
     * @param    nazev    název předmětu (jedno slovo)
     * @param    popis    popis předmětu (může se jednat o text libovolné délky)
     */
    public Predmet(String nazev, String popis)
    {
        this(nazev, popis, true);
    }

    /**
     * Vrátí název předmětu.
     * 
     * @returns    název předmětu
     */
    public String getNazev()
    {
        return nazev;
    }

    /**
     * Vrátí popis předmětu.
     * 
     * @returns    popis předmětu
     */
    public String getPopis()
    {
        return popis;
    }

    /**
     * Vrátí příznak, zda je předmět přenostilený, nebo ne.
     * 
     * @returns    true, pokud je předmět přenositelný; jinak false
     */
    public boolean isPrenositelny()
    {
        return prenositelny;
    }
    
    

    /**
     * Metoda vrací zda je věc ve věci prozkoumaná
     *
     * @return true - je-li prozkoumaná
     */
    public boolean isProzkoumana() {
        return this.prozkoumana;
    }

    /**
     * Metoda vloží věc do předmětu
     *
     * @param vkladana  -věc, kterou chceme vložit
     */
    public void vlozPredmet (Predmet vkladana) {
        veciUvnitr.add(vkladana);
    }

    /**
     * Nastaví nový popis předmětu.
     * 
     * @param    popis nový popispředmětu
     */
    public void setPopis(String popis)
    {
        this.popis = popis;
    }

    /**
     * Nastaví přenositelnost předmětu.
     * 
     * @param    prenositelny   true, pokud má být předmět přenositelný; jinak false
     */
    public void setPrenositelny(boolean prenositelny)
    {
        this.prenositelny = prenositelny;
    }

    /**
     * Metoda nastavuje, zda je věc prozkoumaná či nikoliv
     *
     * @param isProzkoumana  -true, pokud je prozkoumaná
     */
    public void setProzkoumana (boolean prozkoumana) {
        this.prozkoumana = prozkoumana;
    }

    /**
     * Metoda zjistí jestli se věc nachází v jiné předměty.
     *
     * @param nazev     -název hledané věci
     * @return true     -pokud se věc v této věci najde
     */
    public boolean obsahujePredmet(String nazev) {
        boolean obsahuje = false;
        for (Predmet predmet: veciUvnitr) {
            if(predmet.getNazev().equals(nazev)) {
                obsahuje = true;
                break;
            }
        }
        return obsahuje;
    }

    /**
     * Metoda vrací seznam věcí v jiné věci
     *
     * @return veciUvnitr -seznam věcí uvnitř určitý předmět
     */
    public Collection<Predmet> getVeciUvnitr() {
        return veciUvnitr;
    }

    /**
     * Metoda při prozkoumání předměty vrací popis předměty, pokud v tom předmětu obsahuje ještě jiné věci,
     * tak vypíše seznam věci, které jsou ve vnitř
     * @return popis předmětu, pokud neobsahuje jiné věci; seznam věci, pokud předmět obsahuje jiné věci.
     */
    public String popisProzkoumej()
    {
        String text = "";
        if (veciUvnitr.isEmpty())
        {
            text += popis;
        }
        else
        {
            text = "V " + nazev + " jsi našel: ";
            //
            
            //
            for(Predmet predmet : veciUvnitr)
            {
                text +=predmet.getNazev() + ", ";
            }
        }
        return text;
    }

    /**
     * Metoda odebere předmět pokud je přenositelný
     * @param název předmět, který chceme odebírat
     * @return předmět, který chceme odebírat
     */
    public Predmet odeberVec(String nazev)
    {
        Predmet odebiranaVec = null; 
        for (Predmet predmet : veciUvnitr)
        { 
            if (predmet.getNazev().equals(nazev))
            { 
                odebiranaVec = predmet; 
            } 
        } 

        if (odebiranaVec != null)
        { 
            if (odebiranaVec.isPrenositelny())
            { 
                veciUvnitr.remove(odebiranaVec); 
            } 
            else
            { 
                odebiranaVec = null; 
            } 
        }
        return odebiranaVec; 
    }

    /**
     * Metoda vrácí název předmětu
     */
    @Override
    public String toString()
    {
        return "Predmet: " + nazev;
    }

}
