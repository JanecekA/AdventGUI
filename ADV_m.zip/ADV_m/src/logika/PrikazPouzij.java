/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;

/*******************************************************************************
 * Třída PrikazOdemkni implementuje pro hru příkaz odemkni.
 *
 * @author    Antonio Janeček
 * @version   1.1
 */
public class PrikazPouzij implements IPrikaz
{
    //== Datové atributy (statické i instancí)======================================

    private static final String NAZEV = "pouzij";
    private HerniPlan hPlan;
    //== Konstruktory a tovární metody =============================================

    /***************************************************************************
     *  Konstruktor ...
     *  @param hPlan, herní plán, ve kterém se předměty používají
     */
    public PrikazPouzij(HerniPlan hPlan)
    {
        this.hPlan = hPlan;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================

    /**
     *  Metoda pro provedení příkazu pouzij. 
     *  Odemkne prostor pokud splňuje tyto podmínky:
     *  pokud má v batohu používaný předmět
     *  a pokud se cílový objekt nachází v lokaci, případně v inventáří (nepřímo, používaný předmět je spojený s lokací, která se následkem otevře).
     *  
     *  @param predmet_1 predmet_2
     *  @return zpráva, která vypíše výsledek
     */
    
    
    
    
    
    
    
    
    public String proved(String... parametry)
    {
        
    	
    	
    	if (parametry.length <2)
        {           
            return "Musíš zadat platnou kombinaci!";
        }
        String objekt = parametry[1];
        String prostor = "";
        Lokace sousedniProstor = hPlan.getAktualniLokace().vratSousedniLokaci(prostor);
        
        Batoh batoh = hPlan.getBatoh();
        
        if (objekt.equals("mriz")) {
        	
        	prostor = "koridor";
        	sousedniProstor = hPlan.getAktualniLokace().vratSousedniLokaci(prostor);
        }
        
        else if (objekt.equals("zavora")) {
        	
        	prostor = "jidelna";
        	sousedniProstor = hPlan.getAktualniLokace().vratSousedniLokaci(prostor);
        }
        
        else if (objekt.equals("dvere")) {
        	
        	prostor = "sklad";
        	sousedniProstor = hPlan.getAktualniLokace().vratSousedniLokaci(prostor);
        }
        
        else if (objekt.equals("brana")) {
        	
        	prostor = "chodba";
        	sousedniProstor = hPlan.getAktualniLokace().vratSousedniLokaci(prostor);
        }
        
        else if (objekt.equals("dira")) {
        	
        	prostor = "tajna_komora";
        	sousedniProstor = hPlan.getAktualniLokace().vratSousedniLokaci(prostor);
        }
        
        else if (objekt.equals("runa")) {
        	
        	prostor = "vez";
        	sousedniProstor = hPlan.getAktualniLokace().vratSousedniLokaci(prostor);
        }
        
        else if (objekt.equals("kotouc")) {
        	
        	prostor = "povrch";
        	sousedniProstor = hPlan.getAktualniLokace().vratSousedniLokaci(prostor);
        }
       
        if (batoh.obsahujePredmet(parametry[0])&&batoh.obsahujePredmet(parametry[1])) {
        	if(parametry[0].equals("denik")&&parametry[1].equals("kniha"))
        	{
        		Predmet kouzlo = new Predmet("kouzlo", "Zaklínadlo z kouzelné knihy, slouží na zapuzení čarodějnic.", true);
        		batoh.vlozPredmet(kouzlo);
            
        		return "Pomocí deníku jsi našel kouzlo v knize";
        	}
        }   
        
        if (parametry.length==2&&batoh.obsahujePredmet(parametry[0])) { 
        
        	if(parametry[0].equals("kouzlo")&&parametry[1].equals("carodejnice")&&hPlan.getAktualniLokace().getNazev().equals("vez"))
        	{
            
        		batoh.smazPredmet("kouzlo");
        		Predmet krystal = new Predmet("krystal", "Jasný rudý krystal, ten se hodí.", true);
        		batoh.vlozPredmet(krystal);
        		return "carodejnice: AAARGH!!! \n" + "Rog: Safra ta se roztrhla, hle... Vypadl z ní krystal!";
            
        }
        }
        
        if (sousedniProstor == null) {
            return "Neplatná akce!";
            
        
            
            
        }
        else {     
        	
        	
        	if (sousedniProstor.isZamcena()&&parametry.length==2&&batoh.obsahujePredmet(parametry[0])) { 
                if (parametry[0].equals("korbel")&&parametry[1].equals("mriz")) { 
                    sousedniProstor.setZamcena(false);
                    
                    return "Napil jsi se piva z korbele a získal jsi nevídanou sílu! Rozevřel jsi mříže a otevřel si cestu do koridoru...";
                                              
                } 
                else if(parametry[0].equals("sekyra")&&parametry[1].equals("zavora")) {
                    sousedniProstor.setZamcena(false);
                    
                    return "Odrazil jsi sekyrou závoru a uvolnil dveře do jídelny.";
                    
                }
                else if(parametry[0].equals("klika")&&parametry[1].equals("dvere")) {
                    sousedniProstor.setZamcena(false);
                    batoh.smazPredmet("klika");
                    return "Vsadil jsi kliku do dveří a ty jdou teď otevřít.";
                    
                }
                
                else if(parametry[0].equals("paka")&&parametry[1].equals("dira")) {
                    sousedniProstor.setZamcena(false);
                    batoh.smazPredmet("paka");
                    return "S vervou jsi vrazil páku do otvoru a po vypětí sil se ti podařilo aktivovat mechanismus, který otevřel tajnou komoru za knihovnou.";
                     
                }
                
                else if(parametry[0].equals("klic")&&parametry[1].equals("brana")) {
                    sousedniProstor.setZamcena(false);
                    
                    return "Právě jsi odemkl dveře do chodby pomocí klíče."; 
                }
                else if(parametry[0].equals("kniha")&&parametry[1].equals("runa"))
                {
                    sousedniProstor.setZamcena(false);
                    
                    return "Přečetl jsi zaklínadlo z knihy a runa na zemi přestala svítit...";
                    
                }
                
                else if(parametry[0].equals("krystal")&&parametry[1].equals("kotouc"))
                {
                    sousedniProstor.setZamcena(false);
                    batoh.smazPredmet("krystal");
                    return "Vložil jsi krystal do kotouče a náhle se před tebou otevřel portál na povrch.";
                    
                }
                
                else if(parametry[0].equals("kouzlo")&&parametry[1].equals("carodejnice"))
                {
                    
                    batoh.smazPredmet("kouzlo");
                    Predmet krystal = new Predmet("krystal", "Jasný rudý krystal, ten se hodí.", true);
                    batoh.vlozPredmet(krystal);
                    return "carodejnice: AAARGH!!! \n" + "Rog: Safra ta se roztrhla, hle... Vypadl z ní krystal!";
                    
                }
                
                
                else
                {
                    return "Špatná kombinace!";
                }
            }
            return "Neplatná akce!";
        }
    }

    /**
     *  Metoda vrací název příkazu
     *  
     *  @return nazev prikazu
     */
    public String getNazev()
    {
        return NAZEV;
    }
    //== Soukromé metody (instancí i třídy) ========================================

}
