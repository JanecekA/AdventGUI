/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;

/*******************************************************************************
 * Třída PrikazMluv implementuje pro hru příkaz mluv
 *
 * @author    Antonio Janeček
 * @version   1.1
 */
public class PrikazMluv implements IPrikaz
{
    //== Datové atributy (statické i instancí)======================================

    private static final String NAZEV = "mluv";
    private HerniPlan hPlan;
    //== Konstruktory a tovární metody =============================================

    /***************************************************************************
     *  Konstruktor ....
     *  @param hPlan, herní plán, ve kterém se budou postavy mluvit s hračem
     */
    public PrikazMluv(HerniPlan hPlan)
    {
        this.hPlan = hPlan;
    }

    //== Nesoukromé metody (instancí i třídy) ======================================
    /**
     *  Metoda pro provedení příkazu mluv. S postavou lze mluvit pokud je v aktualním lokací.
     *  
     *  @param postava, jméno postavy se kterou chceme mluvit
     *  @return proslov/doslov
     *  
     */
    public String proved(String... parametry)
    {
        if (parametry.length == 0)
        {
            return "S kým chceš mluvit? Musíš zadat jméno postavy";
        }
        String osoba = parametry[0];
        Lokace aktualniLokace = hPlan.getAktualniLokace();
        Postava postava = aktualniLokace.isPostava(osoba);
        if (postava != null)
        {
            return osoba + ": " + postava.getMluv();
        }
        return "Tato postava tu není!";
    }

    /**
     *  Metoda vrací název příkazu (slovo které používá hráč pro jeho vyvolání)
     *  
     *  @return nazev prikazu
     */
    public String getNazev()
    {
        return NAZEV;
    }

    //== Soukromé metody (instancí i třídy) ========================================

}
