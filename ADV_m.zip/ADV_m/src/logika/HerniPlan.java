/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;

import java.util.ArrayList;
import java.util.List;

import utils.Observer;
import utils.Subject;

/**
 * Class HerniPlan - třída představující mapu a stav adventury.
 * 
 * Tato třída inicializuje prvky ze kterých se hra skládá:
 * vytváří všechny lokace, propojuje je vzájemně pomocí východů 
 * a pamatuje si aktuální lokaci, ve které se hráč právě nachází.
 *
 * @author     Michael Kolling, Lubos Pavlicek, Jarmila Pavlickova, Jan Riha, Tran Nhat Duc
 * @version    1.1
 */
public class HerniPlan implements Subject{

    private static final String NAZEV_VITEZNE_LOKACE = "povrch";

    private Lokace aktualniLokace;

    private Batoh batoh;

    private List<Observer> listObserveru = new ArrayList<Observer>();
    /**
     * Konstruktor který vytváří jednotlivé lokace a propojuje je pomocí východů.
     */
    public HerniPlan() {
        zalozLokaceHry();

        this.batoh = new Batoh();
    }

    /**
     * Vytváří jednotlivé lokace a propojuje je pomocí východů.
     * Jako výchozí aktuální lokaci nastaví domeček.
     */
    private void zalozLokaceHry() {
        // vytvářejí se jednotlivé lokace
        
        Lokace cela = new Lokace("cela","Cela. tmavá, zatuchlá cela, naproti jsou staré mříže, které by mohli jít roztáhnout...",0,0);
        Lokace koridor = new Lokace("koridor","Koridor, osvícené světlem louče, vedou odsud dveře do zbrojnice a do kasáren",10,10);
        Lokace zbrojnice = new Lokace("zbrojnice","Zbrojnice. místnost plná zbraní, v rohu stojí podstavec se sekerami",20,20);
        Lokace kasarna = new Lokace("kasarna","Kasárna. Zde běžně spává stráž, vedou odsud dveře kamsi",30,30);
        Lokace jidelna = new Lokace("jidelna","Jídelna. Tady se obědvá, rozsáhlá místnost s několika východy, u dveří do skladu leží přivázaný pes. Knihovna vedle krbu by mohla něco skrývat, je vedle ní kulatá díra...",40,40);
        Lokace sklad = new Lokace("sklad","Sklad. všude samé krámy, na konci za regály leží na zemi velká páka",50,50);
        Lokace tajna_komora = new Lokace("tajna_komora","tajne místo za knihovnou v jídelně, na křesle u stolu uprostřed místnosti sedí kostlivec.",60,60);
        Lokace chodba = new Lokace("chodba","Chodba. Vede do rozsháhlé knihovny. Též do ní ústí schody věže.",70,70);
        Lokace knihovna = new Lokace("knihovna","Knihovna. všude knihy, po straně u okna je menší studovna s masivním dubovým stolem.",80,80);
        Lokace vez = new Lokace("vez","Vež. vysoká, temná věž. Na zemi jsou nakresleny obrazce a uprostřed stojí čarodejnice a hlasitě zaříkává...",90,90);
        Lokace vez2 = new Lokace("vez2","Vež. vysoká, temná věž. Na zemi jsou nakresleny obrazce a uprostřed leží mrtvá čarodejnice, všiml sis kotouče na postaveného na konci u okna.",100,100);
        Lokace povrch = new Lokace("povrch", "Povrch. Konečně jsi se dostal na čerstvý vzduch, co teď? jdem to zapít!",110,110);
        
     
        
        // přiřazují se průchody mezi lokacemi (sousedící lokace)
        
        
        cela.setVychod(koridor);
        koridor.setVychod(zbrojnice);
        koridor.setVychod(cela);
        koridor.setVychod(kasarna);
        zbrojnice.setVychod(koridor);
        kasarna.setVychod(koridor);
        kasarna.setVychod(jidelna);
        jidelna.setVychod(kasarna);
        jidelna.setVychod(sklad);        
        jidelna.setVychod(tajna_komora);
        jidelna.setVychod(chodba);
        sklad.setVychod(jidelna);
        tajna_komora.setVychod(jidelna);
        chodba.setVychod(jidelna);
        chodba.setVychod(knihovna);
        chodba.setVychod(vez);
        knihovna.setVychod(chodba);
        vez.setVychod(chodba);
        vez.setVychod(povrch);
        
        
        
     
        // vytvoříme několik věcí
        Predmet korbel = new Predmet("korbel", "pivní korbel trpaslíka, je v něm trochu piva.", true);
        Predmet podstavec = new Predmet("podstavec","Podstavec plný zbraní, jsou na něm vyskládané sekery.", false);
        Predmet sekyra = new Predmet("sekyra", "robustní sekyra.", true);
        Predmet talir = new Predmet("talir", "talir se zbytky jidla.", false);
        Predmet kost = new Predmet("kost", "kost pochybného původu.", true);
        Predmet klic = new Predmet("klic", "tajemný klic.", true);
        Predmet stul = new Predmet("stul", "stůl plný harampádí.", false);
        Predmet kniha = new Predmet("kniha", "kniha zaklínadel.", true);
        Predmet paka = new Predmet("paka", "velká páka ve zdi.", true);
        Predmet klika = new Predmet("klika", "klika od dveří.", true);
        Predmet prsten = new Predmet("prsten", "Zlatý prsten vysazený modrým kamenem.", true);
        Predmet denik = new Predmet("denik", "Písmo je částečně rozmazané, přečteš jen: '...Hrůza! zlá čarodějnice obsadila pevnost! jediná naděje je kniha kouzel! Na straně 32 najdeš zaklínadlo na vyhnání čarodějnice.", true);
        Predmet mriz = new Predmet("mriz", "Masivní mříž, blokující přístup do koridoru.", false);
        Predmet zavora = new Predmet("zavora", "Velká závora blokující dveře.", false);
        Predmet dvere = new Predmet("dvere", "Dveře do skladu, kterým chybí klika.", false);
        Predmet brana = new Predmet("brana", "Brána, která vede do chodby, zamčená.", false);
        Predmet dira = new Predmet("dira", "Díra vedle knihovničky, má kruhový tvar.", false);
        Predmet runa = new Predmet("runa", "Na zemi leží magický obrazec...", false);
        Predmet krystal = new Predmet("krystal", "Jasný rudý krystal, ten se hodí.", true);
        Predmet kotouc = new Predmet("kotouc", "Kotouč kruhového tvaru s úchopky na malý objekt, stojí na konci místnosti.", false);
        Predmet dummy = new Predmet("dummy", "Testovní objekt", true);
        
        	
        
        
        
      

        // umístíme věci do prostorů a věc do předmět
        
        cela.vlozPredmet(korbel);
        cela.vlozPredmet(mriz);
        kasarna.vlozPredmet(prsten);
        kasarna.vlozPredmet(zavora);
        zbrojnice.vlozPredmet(podstavec);
        podstavec.vlozPredmet(sekyra);
        jidelna.vlozPredmet(talir);
        jidelna.vlozPredmet(dvere);
        jidelna.vlozPredmet(brana);
        jidelna.vlozPredmet(dira);
        talir.vlozPredmet(kost);
        sklad.vlozPredmet(paka);
        knihovna.vlozPredmet(stul);
        stul.vlozPredmet(kniha);
        stul.vlozPredmet(denik);
        chodba.vlozPredmet(runa);
        vez.vlozPredmet(kotouc);
     
        
     
        
     

        // zamceno
        
        koridor.setZamcena(true);
        koridor.setKlic(korbel);
        jidelna.setZamcena(true);
        jidelna.setKlic(sekyra);
        sklad.setZamcena(true);
        sklad.setKlic(klika);
        tajna_komora.setZamcena(true);
        tajna_komora.setKlic(paka);
        chodba.setZamcena(true);
        chodba.setKlic(klic);
        vez.setZamcena(true);
        vez.setKlic(kniha);
        povrch.setZamcena(true);
        povrch.setKlic(krystal);
        
       
        //vytvareni postavy
        
        
        
        jidelna.vlozPostavu(new Postava("pes", " vrrrrr \n"+"Rog: to psisko se od dveří ani nehne", "Rog: konečně si mě nevšímá", " slint slint... vrrrr... \n"+"Rog: asi špatná dobrota...", " Haf Haf! \n"+"Rog: A hele! klika od dveří! To mám ale kliku!", kost, klika));
        tajna_komora.vlozPostavu(new Postava("kostlivec", " Já jsem Smil Flek z Nohavic a dlím tu celou věčnost cizinče! Dones mi můj prsten a dám ti na oplátku klíč k chodbě venku! \n"+"Rog: Jak myslíš starouši...", " Díky cizinče! Tady je klíč... \n"+"Rog: Díky kémo!", " To není můj prsten! \n"+"Rog: To mňa mrzí starouši...", " Ano! To je on! mockrát děkuji! \n" + "Rog: Za málo, ať slóží...", prsten, klic ));
        vez.vlozPostavu(new Postava("carodejnice", " HMMMMMMM.... \n"+"Rog: Nějak si mě nevšíma... asi je v tranzu...", "..."));
        vez2.vlozPostavu(new Postava("carodejnice", " .... \n"+"Rog: Mrtvá čarodejnice, tolik k exorcismu...", "..."));
        
        
        
       
        
        
     
        
        
        aktualniLokace = cela;  // hra začíná v cele      
    }

    /**
     * Metoda vrací odkaz na aktuální lokaci, ve které se hráč právě nachází.
     *
     * @return    aktuální lokace
     */

    public Lokace getAktualniLokace() {
        return aktualniLokace;
    }

    /**
     * Metoda nastaví aktuální lokaci, používá se nejčastěji při přechodu mezi lokacemi
     *
     * @param    lokace nová aktuální lokace
     */
    public void setAktualniLokace(Lokace lokace) {
        aktualniLokace = lokace;
        notifyAlllObservers();
    }

    /**
     * Metoda vrací informaci, zda hráč vyhrál (zda dorazil do lokace domecek).
     * 
     * @return    true, pokud hráč vyhrál; jinak false
     */
    public boolean hracVyhral() {
        return aktualniLokace.getNazev().equals(NAZEV_VITEZNE_LOKACE);
        
    }

    /**
     *  Metoda vrací batoh/inventar, který je během hry používán
     * 
     *  @return    batoh    batoh používaný ve hře
     */
    public Batoh getBatoh() {
        return this.batoh;
    }
    
    /**
     * Metoda registruje observera k pozorování událostí týkajícíh se herního plánu.
     * @param observer - parametrem je observer (instance třídy, která pozoruje).
     */ 
    @Override
    public void registerObserver(Observer observer) {
        listObserveru.add(observer);
    }
    /**
     * Metoda ruší registraci observera k pozorování událostí týkajícíh se herního plánu.
     * @param observer - parametrem je observer (instance třídy, která pozoruje).
     */ 
    @Override
    public void deleteObserver(Observer observer) {
        listObserveru.remove(observer);

    }
    /**
     * Metoda notifikuje všechny observery = volá na ně metodu update().
     */ 
    @Override
    public void notifyAlllObservers() {
        for (Observer listObserveruItem : listObserveru) {
            listObserveruItem.update();
        }
    }
    

}
