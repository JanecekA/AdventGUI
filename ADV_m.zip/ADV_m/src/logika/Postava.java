/* Soubor je ulozen v kodovani UTF-8.
 * Kontrola kódování: Příliš žluťoučký kůň úpěl ďábelské ódy. */
package logika;

/*******************************************************************************
 * Třída Postava popisuje postavy ve hře.
 *
 * Postava je v určeném prosrotu. Kažká postava má jméno a určený proslov. 
 * S postavou můžeme vyměňovat věci.
 *
 * @author    Antonio Janeček
 * @version   1.1
 */
public class Postava
{
    //== Datové atributy (statické i instancí)======================================
    private String jmeno;
    private String proslov;
    private String doslov;
    private Predmet predmetChce;
    private Predmet predmetMa;
    private String recVecNechce;
    private String recVecChce;
    private boolean probehlaVymena = false;
    //== Konstruktory a tovární metody =============================================
    /***************************************************************************
     *  Konstruktor vytváří postavu, která bude mít pouze proslov
     *  @param jmeno, jméno postavy
     *  @param proslov, řeč kterou říká postava
     *  @param recVecNechce, řeč kterou říká postava pokud předmět nechce
     */
    public Postava(String jmeno, String proslov, String recVecNechce)
    {
        this.jmeno = jmeno;
        this.proslov = proslov;
        this.recVecNechce = recVecNechce;
    }

    /***************************************************************************
     *  Konstruktor vytváří postavu pro výměnu
     *  @param jmeno, jméno postavy
     *  @param proslov, řeč kterou říká postava
     *  @param doslov, řeč kterou říká postava po výměně
     *  @param recVecNechce, řeč kterou říká postava pokud předmět nechce
     *  @param recVecChce, řeč kterou říká postava pokud předmět chce
     *  @param predmetChce, předmět kterou postava chce
     *  @param predmetMa, předmět kterou postava má
     */
    public Postava(String jmeno, String proslov, String doslov, String recVecNechce, String recVecChce, Predmet predmetChce, Predmet predmetMa) // postava pro vymenu
    {
        this.jmeno = jmeno;
        this.proslov = proslov;
        this.doslov = doslov;
        this.recVecNechce = recVecNechce;
        this.recVecChce = recVecChce;
        this.predmetChce = predmetChce;
        this.predmetMa = predmetMa;
    }
    //== Nesoukromé metody (instancí i třídy) ======================================
    /**
     * Metoda vrací jméno postavy
     * @return jméno
     */
    public String getJmeno()
    {
        return jmeno;
    }

    /**
     * Metoda vrací proslov postavy
     * @return proslov
     */
    public String getProslov()
    {
        return proslov;
    }

    /**
     * Metoda vrací doslov postavy, řeč postavy po úspěné výměně
     * @return doslov
     */
    public String getDoslov()
    {
        return doslov;
    }

    /**
     * Metoda vrací předmět co postava od nás chce
     * @return věc
     */
    public Predmet getPredmetChce()
    {
        return predmetChce;
    }

    /**
     * Metoda vrací předmět co postava má a vymění za předmět co chce
     * @return předmět
     */
    public Predmet getPredmetMa()
    {
        return predmetMa;
    }

    /**
     * Metoda vrací řeč postavy, že předmět chce
     * @return řeč
     */
    public String getRecChci()
    {
        return recVecChce;
    }

    /**
     * Metoda vrací řeč postavy, že předmět nechce
     * @return řeč
     */
    public String getRecNechci()
    {
        return recVecNechce;
    }

    /**
     * Metoda vrací stav výměny, zda už proběhla výměna nebo ještě ne
     * @return true, pokud výměna úspěšně proběhla
     */
    public boolean probehlaVymena()
    {
        return probehlaVymena;
    }

    /**
     * Metoda pro nastavení stavu výměny, zda už proběhla výměna nebo ještě ne
     * @param true, už proběhla výměna, false, jestě ne
     */
    public void setProbehlaVymena(boolean probehlaVymena)
    {
        this.probehlaVymena = probehlaVymena;
    }

    /**
     * Metoda vrací řeč, na základě toho zda už proběhla výměna nebo ještě ne
     * @return doslov, pokud pokud výměna úspěšně proběhla výměně v opačném případě vrací proslov
     */
    public String getMluv()
    {
        if (probehlaVymena)
        {
            return doslov;
        }
        else
        {
            return proslov;
        }
    }
}